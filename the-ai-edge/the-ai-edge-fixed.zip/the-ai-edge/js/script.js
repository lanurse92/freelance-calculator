function animateValue(id, start, end, duration, prefix = "", suffix = "") {

    const element = document.getElementById(id);

    if (!element) return;

    let startTime = null;

    function update(currentTime) {

        if (!startTime) startTime = currentTime;

        const progress = Math.min((currentTime - startTime) / duration, 1);

        const value = Math.floor(progress * (end - start) + start);

        element.textContent =
            prefix +
            value.toLocaleString() +
            suffix;

        if (progress < 1) {
            requestAnimationFrame(update);
        }

    }

    requestAnimationFrame(update);

}

window.addEventListener("load", () => {

    animateValue("rateValue",0,125,1200,"$","/hr");

    animateValue("timeValue",0,12,1000,""," hrs");

    animateValue("annualValue",0,18720,1500,"$");

});
function trackCalculator(){

    gtag('event', 'calculator_completed', {
        calculator_name: 'AI Time Savings Calculator'
    });

}